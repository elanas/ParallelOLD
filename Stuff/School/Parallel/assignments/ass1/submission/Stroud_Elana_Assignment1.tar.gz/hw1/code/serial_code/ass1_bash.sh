#!/bin/bash

rm serialoutput.csv
echo -e "**SERIAL DATA FIRST**\n" >> serialoutput.csv

make

echo -e "\nSerial Data First\n"

declare -i z=20

for i in `seq 1 "$z"`;
    do
        echo -e "\nloop $i\n"
	./serialdata.o

    done 

echo -e "\n\n**SERIAL FILTER FIRST**\n" >> serialoutput.csv
echo -e "\nSerial Filter First\n"
for i in `seq 1 "$z"`;
    do
    echo -e "\nloop $i\n"
    ./serialfilter.o
    done 


