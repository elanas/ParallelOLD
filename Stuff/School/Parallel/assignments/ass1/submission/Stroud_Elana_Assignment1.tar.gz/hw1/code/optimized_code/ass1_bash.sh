!/bin/bash

rm optimizedoutput.csv
echo -e "**Optimizations**\n" >> optimizedoutput.csv
make

echo -e "\nOptimized Tests\n"

declare -i z=20

for i in `seq 1 "$z"`;
    do
    echo -e "\nloop $i\n"
    ./optimizedparallel.o
    done 

