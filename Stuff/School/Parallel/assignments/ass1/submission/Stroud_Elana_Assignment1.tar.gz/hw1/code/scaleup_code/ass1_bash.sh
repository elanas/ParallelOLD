!/bin/bash

rm scaleupoutput.csv
echo -e "**PARALLEL DATA FIRST**\n" >> scaleupoutput.csv
make
echo -e "\nParallel Data First\n"

declare -i z=20

for i in `seq 1 "$z"`;
    do
	echo -e "\nloop $i\n"
    ./paralleldata.o
    done 

echo -e "\n\n**PARALLEL FILTER FIRST**\n" >> scaleupoutput.csv
echo -e "\nParallel Filter First\n"


for i in `seq 1 "$z"`;
    do
    echo -e "\nloop $i\n"
    ./parallelfilter.o
    done 


